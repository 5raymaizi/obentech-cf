"""对冲策略对比: 价格偏移实验 x 3天 (2025-10-10 ~ 2025-10-12)"""
import copy
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
sys.stdout.reconfigure(encoding='utf-8')

from bt.backtester_hedge import BacktesterHedge, log

BASE_CONFIG = {
    'market_setting': {
        'data_path': 'C:/dev/nuts_mm/data',
        'ex_0': 'binance',
        'symbol_0': 'ETH',
        'transaction_fee_taker': 0.00022,
        'transaction_fee_maker': -0.00005,
    },
    'market_info': {
        'load_type': 0,
        'trades_num': 40,
        'tick': 2,
    },
    'policy': {
        'walk_by_midprice': False,
        'interval': 100,
        'order_size': 1,
        'random_seed': 42,
    },
    'log': {
        'do_log': False,
        'do_record': False,
    },
}

STRATEGIES = {
    'maker_0t':      {'wait_seconds': 0, 'taker_threshold': 0.0, 'price_offset_ticks': 0},
    'maker_10t':     {'wait_seconds': 0, 'taker_threshold': 0.0, 'price_offset_ticks': 10},
    'maker_20t':     {'wait_seconds': 0, 'taker_threshold': 0.0, 'price_offset_ticks': 20},
    'wait5s_0t':     {'wait_seconds': 5, 'taker_threshold': 0.0, 'price_offset_ticks': 0},
    'wait5s_10t':    {'wait_seconds': 5, 'taker_threshold': 0.0, 'price_offset_ticks': 10},
    'wait5s_20t':    {'wait_seconds': 5, 'taker_threshold': 0.0, 'price_offset_ticks': 20},
}

DATES = ['2025-10-10', '2025-10-11', '2025-10-12']


def run_one(date, strategy_name, strategy_params):
    config = copy.deepcopy(BASE_CONFIG)
    config['policy'].update(strategy_params)

    symbol = config['market_setting']['symbol_0']
    bt = BacktesterHedge(date, config)
    bt.load_data(
        f"{symbol.lower()}usdt_{date}_depth5",
        f"{symbol.lower()}usdt_{date}_trade",
    )

    bt.do_log = False
    bt.do_record = False
    bt.receive_position()
    bt.handle_inventory()
    bt.last_hedge_time = bt.time

    while bt._run(bt.interval):
        if bt.time - bt.last_hedge_time >= bt._td_hedge_interval:
            bt.handle_inventory()
            bt.last_hedge_time = bt.time

    bt.close()

    n = len(bt.hedge_results)
    if n == 0:
        return None

    slippages = [r['slippage_pct'] for r in bt.hedge_results]
    hedge_times = [r['hedge_time_seconds'] for r in bt.hedge_results]
    taker_count = sum(1 for r in bt.hedge_results if r.get('taker_used'))

    return {
        'date': date,
        'strategy': strategy_name,
        'total': n,
        'taker_count': taker_count,
        'avg_slippage': sum(slippages) / n,
        'max_slippage': max(slippages),
        'min_slippage': min(slippages),
        'std_slippage': (sum((s - sum(slippages) / n) ** 2 for s in slippages) / n) ** 0.5,
        'avg_time': sum(hedge_times) / n,
        'max_time': max(hedge_times),
        'fee': bt.fee_ex0,
        'volume': bt.transaction_volume_total,
    }


if __name__ == '__main__':
    results = []
    for date in DATES:
        for sname, sparams in STRATEGIES.items():
            log.info(f"Running: {date} | {sname}")
            r = run_one(date, sname, sparams)
            if r:
                results.append(r)
                log.info(f"  done: n={r['total']}, slip={r['avg_slippage']:.4f}%, "
                         f"taker={r['taker_count']}, time={r['avg_time']:.1f}s")

    # 逐日明细
    print("\n" + "=" * 120)
    print(f"{'date':<12} {'strategy':<16} {'count':>7} {'taker':>6} "
          f"{'avg_slip%':>10} {'max_slip%':>10} {'std%':>8} {'avg_t(s)':>9} {'max_t(s)':>9}")
    print("-" * 120)
    for r in results:
        print(f"{r['date']:<12} {r['strategy']:<16} {r['total']:>7} {r['taker_count']:>6} "
              f"{r['avg_slippage']:>10.4f} {r['max_slippage']:>10.4f} "
              f"{r['std_slippage']:>8.4f} {r['avg_time']:>9.1f} {r['max_time']:>9.1f}")
    print("=" * 120)

    # 按策略汇总
    print(f"\n{'strategy':<16} {'total':>8} {'taker':>7} {'w_avg_slip%':>12} {'w_avg_t(s)':>11}")
    print("-" * 60)
    for sname in STRATEGIES:
        sr = [r for r in results if r['strategy'] == sname]
        total = sum(r['total'] for r in sr)
        taker = sum(r['taker_count'] for r in sr)
        w_slip = sum(r['avg_slippage'] * r['total'] for r in sr) / total
        w_time = sum(r['avg_time'] * r['total'] for r in sr) / total
        print(f"{sname:<16} {total:>8} {taker:>7} {w_slip:>12.4f} {w_time:>11.1f}")
    print("=" * 60)
