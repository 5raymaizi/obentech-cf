import pandas as pd
import numpy as np
from scipy import stats

INDICATORS = {}


def indicator(name):
    def add(fn):
        INDICATORS[name] = fn
        return fn

    return add


@indicator('rsi')
def cal_rsi(prices: list):
    total_up = 0
    total_down = 0
    # tmp = pd.Series(prices).diff().dropna()
    tmp = pd.Series(prices[::-1]).diff().dropna()
    for p in tmp:
        if p > 0:
            total_up += p
        else:
            total_down += abs(p)

    return 100 * total_up / (total_up + total_down) if total_up + total_down > 0 else 50


@indicator('rho')
def cal_rho(prices: list):
    prices = pd.Series(prices[::-1])
    length = len(prices)
    x_arr = pd.Series(np.arange(1, length + 1))
    res = stats.spearmanr(x_arr, prices)
    return res.correlation, res.pvalue


@indicator('ulb')
def ulb(val, lb, ub):
    return max(min(val, ub), lb)


@indicator('sigma')
def cal_sigma(prices: list):
    sigma = np.std(prices)
    return sigma


@indicator('ema')
def cal_ema(prices):
    length = len(prices)
    prices = np.array(prices)
    weight = np.arange(1, length + 1)
    return np.sum(prices * weight) / np.sum(weight)


@indicator('avedev')
def cal_avedev(prices):
    prices = np.array(prices)
    return np.mean(np.fabs(prices - prices.mean()), axis=0)


@indicator('stti')
def cal_stti(prices):
    open = prices[-1]
    close = prices[0]
    high = max(prices)
    low = min(prices)
    stti = (close - open + 1e-20) / (high - low + 1e-20)
    return stti


@indicator('pvo')
def cal_pvo(volume_used, fast_periods: int, slow_periods: int, x_0_slow: float, y_0_slow: float):
    volume_used = pd.Series(volume_used)
    volume_ema_slow = volume_used.ewm(span=slow_periods, min_periods=int(slow_periods * 0.9)).mean()
    volume_ema_fast = volume_used.ewm(span=fast_periods, min_periods=fast_periods).mean()
    pvo = ((volume_ema_fast - volume_ema_slow) / volume_ema_slow)
    return pvo
