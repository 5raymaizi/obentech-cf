import numpy as np


class Latency:
    def __init__(self, floor: float = 0):
        self.floor = floor

    def sample(self):
        return self.floor


class StochasticLatency(Latency):
    def __init__(self, support: float, seed: int):
        super(StochasticLatency, self).__init__(support)
        # np.random.seed(seed)
        self.rng = np.random.RandomState(seed)


class NormalLatency(StochasticLatency):
    def __init__(self, mu: float, sigma: float, support: float, seed: int):
        super(NormalLatency, self).__init__(support, seed)
        # self.dist = np.random.normal
        self.dist = self.rng.normal
        self.mu = mu
        self.sigma = sigma

    def sample(self):
        return max(0, self.floor + self.dist(self.mu, self.sigma))


class LognormalLatency(StochasticLatency):
    def __init__(self, mu: float, beta: float, support: float, seed: int):
        super(LognormalLatency, self).__init__(support, seed)
        # self.dist = np.random.lognormal
        self.dist = self.rng.lognormal
        self.mu = mu
        self.beta = beta

    def sample(self):
        return max(0, self.floor + self.dist(self.mu, self.beta))
