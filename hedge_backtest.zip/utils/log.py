import logging
import os
import time


def fmt(x):
    return f"{x:.6f}"

def create_logger(logger_name, console=True, handler=True):
    logger = logging.getLogger(logger_name)
    logger.setLevel(level=logging.INFO)
    logger.propagate = False
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")

    if handler:
        path = os.getcwd()
        filename = path + '/' + str(logger_name) + '.log'
        handler = logging.FileHandler(filename, encoding="utf-8")
        # handler = logging.handlers.TimedRotatingFileHandler(filename=filename, when='d', interval=3, backupCount=5,
        #                                                     encoding='utf-8')
        handler.setLevel(logging.INFO)
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    if console:
        console = logging.StreamHandler()
        console.setLevel(logging.INFO)
        console.setFormatter(formatter)
        logger.addHandler(console)
    return logger
