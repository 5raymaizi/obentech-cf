from market.book import Depth
import math


def spread(ask_depth: Depth, bid_depth: Depth):
    return ask_depth.prices[0] - bid_depth.prices[0]


def last_spread(ask_depth: Depth, bid_depth: Depth):
    return ask_depth.last_prices[0] - bid_depth.last_prices[0]


def spread_move(ask_depth: Depth, bid_depth: Depth):
    return spread(ask_depth, bid_depth) - last_spread(ask_depth, bid_depth)


def midprice(ask_depth: Depth, bid_depth: Depth):
    return ask_depth.prices[0] / 2 + bid_depth.prices[0] / 2


def last_midprice(ask_depth: Depth, bid_depth: Depth):
    return ask_depth.last_prices[0] / 2 + bid_depth.last_prices[0] / 2


def midprice_move(ask_depth: Depth, bid_depth: Depth):
    return midprice(ask_depth, bid_depth) - last_midprice(ask_depth, bid_depth)


def microprice(ask_depth: Depth, bid_depth: Depth):
    ap = ask_depth.prices[0]
    bp = bid_depth.prices[0]
    av = ask_depth.total_volume
    bv = bid_depth.total_volume

    div = av + bv
    mpm_a = av * bp
    mpm_b = ap * bv

    return (mpm_a + mpm_b) / div


def last_microprice(ask_depth: Depth, bid_depth: Depth):
    ap = ask_depth.prices[0]
    bp = bid_depth.prices[0]
    av = ask_depth.last_total_volume
    bv = bid_depth.last_total_volume

    div = av + bv
    mpm_a = av * bp
    mpm_b = ap * bv

    return (mpm_a + mpm_b) / div


def microprice_move(ask_depth: Depth, bid_depth: Depth):
    return microprice(ask_depth, bid_depth) - last_microprice(ask_depth, bid_depth)


def price_by_tick_bid(price, tick):
    return math.floor(price * 10 ** tick) / 10 ** tick


def price_by_tick_ask(price, tick):
    return math.ceil(price * 10 ** tick) / 10 ** tick
