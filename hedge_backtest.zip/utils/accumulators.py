from collections import deque
import numpy as np
from sortedcontainers import SortedList

class Accumulator:
    def __init__(self, window_size):
        # self.window = deque(maxlen=window_size)
        self.window = deque()
        self.window_size = window_size
        self._sum = 0

    def push(self, val):
        self._sum += val
        self.window.appendleft(val)

        if self.size > self.window_size:
            self._sum -= self.window.pop()

    @property
    def sum(self):
        return self._sum

    @property
    def size(self):
        return len(self.window)

    @property
    def front(self):
        return self.window[0] if self.size > 0 else -1

    @property
    def back(self):
        return self.window[-1] if self.size > 0 else -1

    def __getitem__(self, i):
        return self.window[i] if i < self.size else -1

    def reset(self):
        self.window = deque()
        self._sum = 0

    def is_full(self):
        return self.size == self.window_size


class RollingMean(Accumulator):
    def __init__(self, window_size):
        super().__init__(window_size)
        self._mean = 0
        self._s = 0
        self.sorted_window = SortedList()  # 用于快速 percentile 计算

    def push(self, val):
        self._sum += val
        self.window.appendleft(val)
        self.sorted_window.add(val)

        n = self.size
        old_mean = self._mean

        self._mean += (val - self._mean) / n
        self._s += (val - self._mean) * (val - old_mean)

        if n > self.window_size:
            old = self.window.pop()
            self._sum -= old
            self.sorted_window.remove(old)

            n = self.size
            old_mean = self._mean

            self._mean -= (old - self._mean) / n
            self._s -= (old - self._mean) * (old - old_mean)

    @property
    def mean(self):
        return self._mean

    @property
    def var(self):
        if self.size < 2:
            return 0
        return self._s / (self.size - 1)

    @property
    def std(self):
        v = self.var
        return np.sqrt(v) if v > 0 else 0

    @property
    def zscore(self, val):
        std = self.std()
        return (val - self.mean) / std if std > 0 else 0

    @property
    def last_zscore(self):
        return self.zscore(self.front())

    def percentile(self, q):
        """使用 SortedList 快速计算 percentile，O(1) 访问"""
        n = len(self.sorted_window)
        if n == 0:
            return 0
        pos = q * (n - 1)
        lower = int(pos)
        upper = min(lower + 1, n - 1)
        if lower == upper:
            return self.sorted_window[lower]
        # 线性插值
        return self.sorted_window[lower] + (self.sorted_window[upper] - self.sorted_window[lower]) * (pos - lower)

    def reset(self):
        super().reset()
        self.sorted_window.clear()


class EWMA(Accumulator):
    def __init__(self, window_size):
        super().__init__(window_size)
        self._alpha = 2 / (window_size + 1)
        self._mean = 0

    def push(self, val):
        self.window.appendleft(val)
        self.window.pop()

        self._mean = self._alpha * val + (1 - self._alpha) * self._mean

    @property
    def mean(self):
        return self._mean


class RollingMedian(Accumulator):
    def __init__(self, window_size):
        super().__init__(window_size)

    @property
    def median(self):
        return np.median(self.window)

    @property
    def quartile(self, q):
        if self.size() < 3:
            return self.median()
        return np.quantile(self.window, q)

    @property
    def iqr(self):
        return self.quartile(0.75) - self.quartile(0.25)

    @property
    def min(self):
        return min(self.window)

    @property
    def max(self):
        return max(self.window)

    @property
    def zscore(self, val):
        iqr = self.iqr()
        return (val - self.median()) / iqr if iqr > 0 else 0

    @property
    def last_zscore(self):
        return self.zscore(self.front())


class RollingRate(RollingMean):
    def __init__(self, window_size):
        super().__init__(window_size)

    @property
    def rate(self):
        if self.is_full():
            return self.sum()/self.window_size
        else:
            return -1


class EfficientRollingMean:
    def __init__(self, window_size):
        self.window_size = window_size
        self.window = deque()
        self.sorted_window = SortedList()
        self._sum = 0.0
        self._mean = 0.0
        self._s = 0.0  # Welford's sum of squares

    def push(self, val):
        self.window.appendleft(val)
        self.sorted_window.add(val)
        self._sum += val

        n = len(self.window)
        old_mean = self._mean
        self._mean += (val - self._mean) / n
        self._s += (val - self._mean) * (val - old_mean)

        if n > self.window_size:
            old = self.window.pop()
            self.sorted_window.remove(old)
            self._sum -= old

            n -= 1
            old_mean = self._mean
            self._mean -= (old - self._mean) / n
            self._s -= (old - self._mean) * (old - old_mean)

    @property
    def mean(self):
        return self._mean

    @property
    def std(self):
        n = len(self.window)
        if n < 2:
            return 0.0
        return np.sqrt(self._s / (n - 1))

    def percentile(self, q):
        """
        Returns the q-percentile value in the window (like np.percentile, method='linear').
        q should be a float between 0 and 1.
        """
        n = len(self.sorted_window)
        if n == 0:
            return None
        pos = q * (n - 1)
        lower = int(np.floor(pos))
        upper = int(np.ceil(pos))
        if lower == upper:
            return self.sorted_window[int(pos)]
        lower_value = self.sorted_window[lower]
        upper_value = self.sorted_window[upper]
        # 线性插值，和 np.percentile 一致
        return lower_value + (upper_value - lower_value) * (pos - lower)

    def zscore(self, val):
        std = self.std
        return (val - self.mean) / std if std > 0 else 0

    @property
    def last_zscore(self):
        if self.window:
            return self.zscore(self.window[0])
        return 0

    def reset(self):
        self.window.clear()
        self.sorted_window.clear()
        self._sum = 0.0
        self._mean = 0.0
        self._s = 0.0

    @property
    def sum(self):
        return self._sum

    @property
    def size(self):
        return len(self.window)

    @property
    def front(self):
        return self.window[0] if self.size > 0 else -1

    @property
    def back(self):
        return self.window[-1] if self.size > 0 else -1

    def __getitem__(self, i):
        return self.window[i] if i < self.size else -1

    def is_full(self):
        return self.size == self.window_size


class SimpleRollingMean:
    """不需要 percentile 功能的轻量级滚动均值，避免 SortedList 开销"""
    __slots__ = ['window_size', 'window', '_sum', '_mean', '_s']

    def __init__(self, window_size):
        self.window_size = window_size
        self.window = deque()
        self._sum = 0.0
        self._mean = 0.0
        self._s = 0.0

    def push(self, val):
        self.window.appendleft(val)
        self._sum += val

        n = len(self.window)
        old_mean = self._mean
        self._mean += (val - self._mean) / n
        self._s += (val - self._mean) * (val - old_mean)

        if n > self.window_size:
            old = self.window.pop()
            self._sum -= old

            n -= 1
            old_mean = self._mean
            self._mean -= (old - self._mean) / n
            self._s -= (old - self._mean) * (old - old_mean)

    @property
    def mean(self):
        return self._mean

    @property
    def sum(self):
        return self._sum

    @property
    def size(self):
        return len(self.window)

    @property
    def front(self):
        return self.window[0] if self.window else -1

    @property
    def back(self):
        return self.window[-1] if self.window else -1

    def is_full(self):
        return len(self.window) == self.window_size
