from market.book import *
from market.data_loader0612 import *
from market.trade import *
from utils.log import *
from utils.accumulators import *
from utils.measures import *
from utils.indicator import *
from utils.latency import *
from datetime import timedelta, datetime
import json
import random

_TD_1_SECOND = timedelta(seconds=1)
_TD_1_HOUR = timedelta(hours=1)

DATE = datetime.now().strftime("%y-%m-%d")
log = create_logger(f"backtest_hedge_{DATE}", handler=True, console=True)


class Side(Enum):
    Bid, Ask = 0, 1


class OrderType(Enum):
    Maker_bid, Maker_ask, Taker_bid, Taker_ask = 0, 1, 2, 3


SIDE_BID = Side.Bid
SIDE_ASK = Side.Ask
ORDER_TYPE_NAMES = {
    0: "Maker_bid",
    1: "Maker_ask",
    2: "Taker_bid",
    3: "Taker_ask",
}


class BacktesterHedge:
    """
    对冲回测器:
    - 始终有且仅有一个待对冲头寸, 对冲完成后立即随机获取下一个
    - 多头成本 = bestAsk, 空头成本 = bestBid
    - 通过 handleInventory 进行对冲: 每秒在 bestPrice 挂 maker 单
    - 成交后记录对冲滑点 = (对冲价 - 成本价) / 成本价 * 100%
    """

    def __init__(self, date: str, config: dict):
        ex_0 = str(config["market_setting"]["ex_0"])
        symbol_0 = str(config["market_setting"]["symbol_0"])
        transaction_fee_maker = float(config["market_setting"]["transaction_fee_maker"])
        transaction_fee_taker = float(config["market_setting"]["transaction_fee_taker"])
        data_path = config["market_setting"].get("data_path", "./data")

        load_type = int(config["market_info"]["load_type"])
        trades_num = int(config["market_info"]["trades_num"])
        tick = int(config["market_info"]["tick"])

        walk_by_midprice = bool(config["policy"]["walk_by_midprice"])
        interval = int(config["policy"]["interval"])
        order_size = float(config["policy"]["order_size"])

        # 对冲专用配置
        random_seed = int(config["policy"].get("random_seed", 42))
        wait_seconds = float(config["policy"].get("wait_seconds", 0))
        taker_threshold = float(config["policy"].get("taker_threshold", 0.0))
        hedge_interval_ms = int(config["policy"].get("hedge_interval_ms", 1000))
        price_offset_ticks = int(config["policy"].get("price_offset_ticks", 0))

        do_log = bool(config["log"]["do_log"])
        do_record = bool(config["log"]["do_record"])

        # market_setting
        self.ex0 = ex_0
        self.symbol_0 = symbol_0
        self.maker_fee = transaction_fee_maker
        self.taker_fee = transaction_fee_taker
        self.tick = tick
        self.data_path = data_path

        # market_info
        self.load_type = load_type
        self.market_depth_ex0 = FuturesMarketDepth()
        self.market_trade_ex0 = FuturesMarketTrade()
        self.trades_ex0 = TradeFlow(trades_num)
        self.f_midprice_ex0 = RollingMean(5)
        self.ask_depth_ex0 = Depth()
        self.bid_depth_ex0 = Depth()

        self.date = None
        self.cur_date = None
        self.time = None

        # 账户
        self._position_ex0 = 0
        self.cash_ex0 = 0
        self.fee_ex0 = 0
        self.transaction_volume_total = 0

        # 对冲挂单簿 (每次只挂一个方向的单)
        self.ask_book_ex0 = AskBook()
        self.bid_book_ex0 = BidBook()
        self._td_hedge_interval = timedelta(milliseconds=hedge_interval_ms)
        self.ac_time_interval = self._td_hedge_interval

        # 策略参数
        self.walk_by_midprice = walk_by_midprice
        self.interval = interval
        self.order_size = order_size
        self._td_wait = timedelta(seconds=wait_seconds)
        self.taker_threshold = taker_threshold
        self._price_offset = price_offset_ticks * 10 ** (-tick)  # tick数 → 价格偏移
        # taker 相比 maker 额外的手续费 (用于计入滑点)
        self._fee_penalty = self.taker_fee - self.maker_fee

        # 对冲状态: 始终只有一个 current_hedge, 完成即获取下一个
        self.current_hedge = None           # 当前正在对冲的头寸
        self.hedge_results = []             # 已完成的对冲结果
        self.last_hedge_time = None
        self._rng = random.Random(random_seed)

        # 统计
        self.total_positions_received = 0
        self.total_positions_hedged = 0

        # 日志
        self.path = f"./log/{symbol_0}_hedge/{DATE}/"
        self.do_log = do_log
        self.do_record = do_record
        self.file = f'{date}_{time.time()}.json'

        if not os.path.exists(self.path):
            os.makedirs(self.path, exist_ok=True)

        self._record_file = None
        self._record_buffer = []
        self._record_buffer_limit = 1000
        if self.do_record:
            self._record_file = open(self.path + self.file, "a+", buffering=8192)

    # ==================== 记录 ====================

    def _write_record(self, info: dict):
        if self._record_file:
            self._record_buffer.append(info)
            if len(self._record_buffer) >= self._record_buffer_limit:
                self._flush_records()

    def _flush_records(self):
        if self._record_file and self._record_buffer:
            lines = [json.dumps(info) + "\n" for info in self._record_buffer]
            self._record_file.writelines(lines)
            self._record_buffer.clear()

    def close(self):
        self._flush_records()
        if self._record_file:
            self._record_file.close()
            self._record_file = None

    # ==================== 头寸接收 ====================

    def receive_position(self):
        """
        随机获取一个新的待对冲头寸, 立即设为 current_hedge。
        long 成本 = bestAsk, short 成本 = bestBid
        """
        side = 'long' if self._rng.random() < 0.5 else 'short'
        size = self.order_size

        if side == 'long':
            cost_price = self.ask_depth_ex0.prices[0]  # bestAsk
            self._position_ex0 += size
            self.cash_ex0 -= size * cost_price
        else:
            cost_price = self.bid_depth_ex0.prices[0]  # bestBid
            self._position_ex0 -= size
            self.cash_ex0 += size * cost_price

        self.current_hedge = {
            'side': side,
            'size': size,
            'remaining': size,
            'cost_price': cost_price,
            'receive_time': self.time,
            'fills': [],
            'first_order_placed': False,
        }
        self.total_positions_received += 1

        if self.do_log:
            log.info(
                f"{self.time}, 接收{side}头寸: size={size}, cost={cost_price:.2f}"
            )
        if self.do_record:
            self._write_record({
                'time': str(self.time),
                'event': 'receive_position',
                'side': side,
                'size': size,
                'cost_price': cost_price,
                'position': self._position_ex0,
                'cash': self.cash_ex0,
            })

    # ==================== 对冲逻辑 ====================

    def handle_inventory(self):
        """
        对冲当前头寸 (两阶段):
        Phase 1: 首单挂在 bestPrice, 等待 wait_seconds 秒不刷新
        Phase 2: 超时未成交后, 每秒在最新 bestPrice 刷新挂单
        """
        if self.current_hedge is None:
            return

        h = self.current_hedge

        # Phase 1: 前 wait_seconds 秒, 只挂一次单
        if self.time - h['receive_time'] < self._td_wait:
            if not h['first_order_placed']:
                h['first_order_placed'] = True
                ac_time = h['receive_time'] + self._td_wait
                if h['side'] == 'long':
                    self.ask_book_ex0.place_order(
                        price_by_tick_ask(self.ask_depth_ex0.prices[0] + self._price_offset, self.tick),
                        h['remaining'],
                        ORDER_TYPE_NAMES[1],
                        ac_time,
                    )
                else:
                    self.bid_book_ex0.place_order(
                        price_by_tick_bid(self.bid_depth_ex0.prices[0] - self._price_offset, self.tick),
                        h['remaining'],
                        ORDER_TYPE_NAMES[0],
                        ac_time,
                    )
            return

        # Phase 2: 超时后, 每秒取消旧单并在最新 bestPrice 重挂

        # 检查是否触发 taker 止损
        if self.taker_threshold > 0:
            if h['side'] == 'long':
                current_best = self.ask_depth_ex0.prices[0]
                loss = (h['cost_price'] - current_best) / h['cost_price']
            else:
                current_best = self.bid_depth_ex0.prices[0]
                loss = (current_best - h['cost_price']) / h['cost_price']
            if loss > self.taker_threshold:
                self._taker_hedge()
                return

        self.ask_book_ex0.cancel_all_orders()
        self.bid_book_ex0.cancel_all_orders()

        ac_time = self.time + self.ac_time_interval
        if h['side'] == 'long':
            self.ask_book_ex0.place_order(
                price_by_tick_ask(self.ask_depth_ex0.prices[0] + self._price_offset, self.tick),
                h['remaining'],
                ORDER_TYPE_NAMES[1],
                ac_time,
            )
        else:
            self.bid_book_ex0.place_order(
                price_by_tick_bid(self.bid_depth_ex0.prices[0] - self._price_offset, self.tick),
                h['remaining'],
                ORDER_TYPE_NAMES[0],
                ac_time,
            )

    def _taker_hedge(self):
        """亏损超阈值, taker 立即平仓。用调整价(含额外手续费)计入滑点"""
        h = self.current_hedge
        remaining = h['remaining']

        self.ask_book_ex0.cancel_all_orders()
        self.bid_book_ex0.cancel_all_orders()

        if h['side'] == 'long':
            # taker 卖出 @ bestBid
            fill_price = self.bid_depth_ex0.prices[0]
            value = remaining * fill_price
            self._position_ex0 -= remaining
            self.cash_ex0 += value
            self.fee_ex0 += value * self.taker_fee
            # 调整价: 扣除额外手续费 → 有效卖价更低
            adjusted_price = fill_price * (1 - self._fee_penalty)
        else:
            # taker 买入 @ bestAsk
            fill_price = self.ask_depth_ex0.prices[0]
            value = remaining * fill_price
            self._position_ex0 += remaining
            self.cash_ex0 -= value
            self.fee_ex0 += value * self.taker_fee
            # 调整价: 加上额外手续费 → 有效买价更高
            adjusted_price = fill_price * (1 + self._fee_penalty)

        self.transaction_volume_total += value

        if self.do_log:
            log.info(
                f"{self.time}, taker止损: {h['side']}, "
                f"price={fill_price:.2f}, adj={adjusted_price:.2f}, "
                f"fee_penalty={self._fee_penalty * 100:.4f}%"
            )
        if self.do_record:
            self._write_record({
                'time': str(self.time),
                'event': 'taker_hedge',
                'side': h['side'],
                'fill_price': fill_price,
                'adjusted_price': adjusted_price,
                'volume': remaining,
                'position': self._position_ex0,
                'cash': self.cash_ex0,
            })

        # 用调整价走 _process_hedge_fill → 自动算滑点 + 获取下一个头寸
        h['taker_used'] = True
        self._process_hedge_fill(adjusted_price, remaining)

    # ==================== 撮合与滑点 ====================

    def walk_the_book(self, reference_price: float):
        """检查挂单是否成交, 并跟踪对冲滑点"""
        ask_ret = self.ask_book_ex0.apply_transactions(reference_price, self.time)
        bid_ret = self.bid_book_ex0.apply_transactions(reference_price, self.time)

        # 更新仓位和现金
        self._position_ex0 += ask_ret[0] + bid_ret[0]
        self.cash_ex0 += ask_ret[2] + bid_ret[2]
        self.fee_ex0 += ask_ret[2] * self.maker_fee - bid_ret[2] * self.maker_fee
        self.transaction_volume_total += abs(ask_ret[2]) + abs(bid_ret[2])

        # 处理成交 → 记录对冲滑点
        if self.current_hedge is not None:
            # ask 成交 = 卖出 = 对冲多头
            if len(ask_ret[-1]) != 0 and self.current_hedge['side'] == 'long':
                for (price, volume, order_type, ac_time) in ask_ret[-1]:
                    self._process_hedge_fill(price, volume)
                    if self.do_record:
                        self._write_record({
                            'time': str(self.time),
                            'event': 'hedge_fill',
                            'side': 'long',
                            'fill_price': price,
                            'fill_volume': volume,
                            'type': order_type,
                            'position': self._position_ex0,
                            'cash': self.cash_ex0,
                        })

            # bid 成交 = 买入 = 对冲空头
            if self.current_hedge is not None and len(bid_ret[-1]) != 0 and self.current_hedge['side'] == 'short':
                for (price, volume, order_type, ac_time) in bid_ret[-1]:
                    self._process_hedge_fill(price, volume)
                    if self.do_record:
                        self._write_record({
                            'time': str(self.time),
                            'event': 'hedge_fill',
                            'side': 'short',
                            'fill_price': price,
                            'fill_volume': volume,
                            'type': order_type,
                            'position': self._position_ex0,
                            'cash': self.cash_ex0,
                        })

        return ask_ret, bid_ret

    def _process_hedge_fill(self, fill_price: float, fill_volume: float):
        """记录对冲成交, 完全对冲时计算滑点"""
        h = self.current_hedge
        if h is None:
            return

        h['remaining'] -= fill_volume
        h['fills'].append({
            'price': fill_price,
            'volume': fill_volume,
            'time': str(self.time),
        })

        # 完全对冲
        if h['remaining'] <= 1e-10:
            total_value = sum(f['price'] * f['volume'] for f in h['fills'])
            total_volume = sum(f['volume'] for f in h['fills'])
            avg_hedge_price = total_value / total_volume

            # 滑点统一口径: 正值=亏损, 负值=盈利
            # long:  买入成本 - 卖出对冲价, 正值=卖得比买入低=亏
            # short: 买入对冲价 - 卖出成本, 正值=买得比卖出高=亏
            if h['side'] == 'long':
                slippage_pct = (h['cost_price'] - avg_hedge_price) / h['cost_price'] * 100
            else:
                slippage_pct = (avg_hedge_price - h['cost_price']) / h['cost_price'] * 100
            hedge_time = (self.time - h['receive_time']).total_seconds()

            result = {
                'side': h['side'],
                'size': h['size'],
                'cost_price': h['cost_price'],
                'hedge_price': avg_hedge_price,
                'slippage_pct': slippage_pct,
                'hedge_time_seconds': hedge_time,
                'receive_time': str(h['receive_time']),
                'complete_time': str(self.time),
                'num_fills': len(h['fills']),
                'taker_used': h.get('taker_used', False),
            }
            self.hedge_results.append(result)
            self.total_positions_hedged += 1

            if self.do_log:
                log.info(
                    f"{self.time}, 对冲完成: {h['side']}, "
                    f"成本={h['cost_price']:.2f}, 对冲价={avg_hedge_price:.2f}, "
                    f"滑点={slippage_pct:.4f}%, 耗时={hedge_time:.1f}s"
                )
            if self.do_record:
                self._write_record({
                    'time': str(self.time),
                    'event': 'hedge_complete',
                    **result,
                })

            # 对冲完成, 立即获取下一个头寸
            self.receive_position()

    # ==================== 数据加载 ====================

    def load_data(self, depth_file_ex0, trade_file_ex0):
        if self.load_type == 0:
            self.market_depth_ex0.load_dataset(
                depth_file_ex0, exchange=self.ex0, symbol=self.symbol_0,
                file_type='parquet', data_path=self.data_path
            )
        else:
            self.market_depth_ex0.load_datasets(
                depth_file_ex0, exchange=self.ex0, symbol=self.symbol_0,
                file_type='parquet', data_path=self.data_path
            )

        ask_price = self.market_depth_ex0.ask_prices
        ask_volume = self.market_depth_ex0.ask_volume
        bid_price = self.market_depth_ex0.bid_prices
        bid_volume = self.market_depth_ex0.bid_volume

        self.ask_depth_ex0.update(ask_price, ask_volume)
        self.bid_depth_ex0.update(bid_price, bid_volume)

        mp = midprice(self.ask_depth_ex0, self.bid_depth_ex0)
        self.f_midprice_ex0.push(mp)

        self.date = self.market_depth_ex0.cur_date
        self.cur_date = self.date
        self.time = self.market_depth_ex0.cur_time

        if self.load_type == 0:
            self.market_trade_ex0.load_dataset(
                trade_file_ex0, exchange=self.ex0, symbol=self.symbol_0,
                data_path=self.data_path
            )
        else:
            self.market_trade_ex0.load_datasets(
                trade_file_ex0, exchange=self.ex0, symbol=self.symbol_0,
                data_path=self.data_path
            )

        price = self.market_trade_ex0.price
        volume = self.market_trade_ex0.volume
        side = self.market_trade_ex0.side
        trade_time = self.market_trade_ex0.cur_time
        self.trades_ex0.push(price, volume, trade_time, side)

        # 填充数据结构
        while not (self.f_midprice_ex0.is_full() and self.trades_ex0.is_full()):
            if not self.next():
                return False

    # ==================== tick 迭代 ====================

    def next(self):
        self.ask_depth_ex0.stash_state()
        self.bid_depth_ex0.stash_state()
        while True:
            if not self.market_depth_ex0.load_next():
                return False

            while self.market_trade_ex0.next_time <= self.market_depth_ex0.cur_time:
                if not self.market_trade_ex0.load_next():
                    return False
                self.update_trades()
                if not self.walk_by_midprice:
                    self.walk_the_book(self.market_trade_ex0.price)

            self.update_depth()
            mp = midprice(self.ask_depth_ex0, self.bid_depth_ex0)
            sp = spread(self.ask_depth_ex0, self.bid_depth_ex0)
            mp_move = midprice_move(self.ask_depth_ex0, self.bid_depth_ex0)

            if (
                mp > 0
                and sp >= 0
                and (
                    np.fabs(mp_move) < mp
                    and self.ask_depth_ex0.has_stash() > 0
                    and self.bid_depth_ex0.has_stash() > 0
                )
            ):
                break

        return True

    def update_depth(self):
        ask_price = self.market_depth_ex0.ask_prices
        ask_volume = self.market_depth_ex0.ask_volume
        bid_price = self.market_depth_ex0.bid_prices
        bid_volume = self.market_depth_ex0.bid_volume

        self.ask_depth_ex0.update(ask_price, ask_volume)
        self.bid_depth_ex0.update(bid_price, bid_volume)

        mp = midprice(self.ask_depth_ex0, self.bid_depth_ex0)
        self.f_midprice_ex0.push(mp)

        self.date = self.market_depth_ex0.cur_date
        self.time = self.market_depth_ex0.cur_time

    def update_trades(self):
        price = self.market_trade_ex0.price
        volume = self.market_trade_ex0.volume
        side = self.market_trade_ex0.side
        trade_time = self.market_trade_ex0.cur_time
        self.trades_ex0.push(price, volume, trade_time, side)

    # ==================== 运行 ====================

    def _run(self, interval: int):
        if interval:
            time_start = self.time
            while self.time - time_start <= timedelta(milliseconds=interval):
                if not self.next():
                    if self.do_log:
                        log.info("It is the last tick!")
                    return False
                if self.walk_by_midprice:
                    self.walk_the_book(self.f_midprice_ex0.front)
        else:
            if not self.next():
                if self.do_log:
                    log.info("It is the last tick!")
                return False
            if self.walk_by_midprice:
                self.walk_the_book(self.f_midprice_ex0.front)
        return True

    def run(self):
        if self.do_log:
            log.info("Start hedge backtest!")
        log.info(f"ex0_time:{self.market_depth_ex0.cur_time}, time:{self.time}")

        # 获取第一个待对冲头寸
        self.receive_position()
        self.handle_inventory()

        start_time = self.time
        self.last_hedge_time = self.time

        while self._run(self.interval):
            # 按 hedge_interval 刷新对冲挂单
            if self.time - self.last_hedge_time >= self._td_hedge_interval:
                self.handle_inventory()
                self.last_hedge_time = self.time

            # 每小时日志
            if self.time - start_time > _TD_1_HOUR:
                start_time = self.time
                self._log_hourly_summary()

            # 跨日日志
            if self.date != self.cur_date:
                self._log_daily_summary()
                self.cur_date = self.date

        self._print_hedge_summary()
        self.close()

    # ==================== 日志输出 ====================

    def _log_hourly_summary(self):
        n = len(self.hedge_results)
        if n > 0:
            avg_slippage = sum(r['slippage_pct'] for r in self.hedge_results) / n
            avg_time = sum(r['hedge_time_seconds'] for r in self.hedge_results) / n
        else:
            avg_slippage = 0
            avg_time = 0
        log.info(
            f"{self.time}, 已对冲:{n}/{self.total_positions_received}, "
            f"平均滑点:{avg_slippage:.4f}%, 平均耗时:{avg_time:.1f}s, "
            f"仓位:{self._position_ex0}"
        )

    def _log_daily_summary(self):
        n = len(self.hedge_results)
        if n > 0:
            avg_slippage = sum(r['slippage_pct'] for r in self.hedge_results) / n
        else:
            avg_slippage = 0
        log.info(
            f"{self.cur_date}, 日总结: 对冲完成:{n}, "
            f"平均滑点:{avg_slippage:.4f}%, 总手续费:{self.fee_ex0:.2f}"
        )

    def _print_hedge_summary(self):
        """打印对冲回测总结"""
        n = len(self.hedge_results)

        log.info("=" * 80)
        log.info("对冲回测总结")
        log.info("=" * 80)
        log.info(f"总接收头寸: {self.total_positions_received}")
        log.info(f"总完成对冲: {n}")

        if n > 0:
            slippages = [r['slippage_pct'] for r in self.hedge_results]
            hedge_times = [r['hedge_time_seconds'] for r in self.hedge_results]
            long_results = [r for r in self.hedge_results if r['side'] == 'long']
            short_results = [r for r in self.hedge_results if r['side'] == 'short']

            taker_results = [r for r in self.hedge_results if r.get('taker_used')]
            maker_results = [r for r in self.hedge_results if not r.get('taker_used')]

            log.info(f"  多头对冲: {len(long_results)}")
            log.info(f"  空头对冲: {len(short_results)}")
            log.info(f"  maker对冲: {len(maker_results)}")
            log.info(f"  taker止损: {len(taker_results)}")
            avg_slip = sum(slippages) / n
            log.info(f"平均滑点: {avg_slip:.4f}%")
            log.info(f"最大滑点: {max(slippages):.4f}%")
            log.info(f"最小滑点: {min(slippages):.4f}%")
            std = (sum((s - avg_slip) ** 2 for s in slippages) / n) ** 0.5
            log.info(f"滑点标准差: {std:.4f}%")
            log.info(f"平均对冲耗时: {sum(hedge_times) / n:.1f}s")
            log.info(f"最长对冲耗时: {max(hedge_times):.1f}s")

            if long_results:
                long_slip = [r['slippage_pct'] for r in long_results]
                log.info(f"多头平均滑点: {sum(long_slip) / len(long_slip):.4f}%")
            if short_results:
                short_slip = [r['slippage_pct'] for r in short_results]
                log.info(f"空头平均滑点: {sum(short_slip) / len(short_slip):.4f}%")
            if maker_results:
                maker_slip = [r['slippage_pct'] for r in maker_results]
                log.info(f"maker平均滑点: {sum(maker_slip) / len(maker_slip):.4f}%")
            if taker_results:
                taker_slip = [r['slippage_pct'] for r in taker_results]
                log.info(f"taker平均滑点(含手续费): {sum(taker_slip) / len(taker_slip):.4f}%")

        log.info(f"总手续费: {self.fee_ex0:.2f}")
        log.info(f"总成交量: {self.transaction_volume_total:.2f}")
        log.info(f"最终仓位: {self._position_ex0}")
        log.info(f"最终现金: {self.cash_ex0:.2f}")
        log.info("=" * 80)

        # 导出结果到 JSON
        if self.do_record:
            summary_file = self.path + "hedge_summary.json"
            with open(summary_file, "w") as f:
                json.dump({
                    'total_received': self.total_positions_received,
                    'total_hedged': n,
                    'results': self.hedge_results,
                    'fee': self.fee_ex0,
                    'transaction_volume': self.transaction_volume_total,
                    'final_position': self._position_ex0,
                    'final_cash': self.cash_ex0,
                }, f, indent=2)
            log.info(f"对冲结果已导出到: {summary_file}")
