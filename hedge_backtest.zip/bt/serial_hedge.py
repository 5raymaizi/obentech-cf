import warnings

from bt.backtester_hedge import *

warnings.filterwarnings("ignore")


def backtest_loop_hedge(config: dict, start=0, end=0):
    exchange = config["market_setting"]["ex_0"]
    symbol = config["market_setting"]["symbol_0"]
    load_type = config["market_info"]["load_type"]
    data_path = config["market_setting"].get("data_path", "./data")

    files = os.listdir(f"{data_path}/{exchange}/perp/books/{symbol}")
    symbol_len = len(symbol)
    dates = [_[symbol_len + 5 : symbol_len + 15] for _ in files]
    if end:
        dates = dates[start:end]
    else:
        dates = dates[start:]
    log.info(f"start hedge backtest")
    log.info("=" * 80)
    if load_type == 0:
        for i in range(len(dates)):
            date = dates[i]
            bt = BacktesterHedge(date, config)
            log.info(f"date:{date}, saved in {bt.path}")
            bt.load_data(
                f"{symbol.lower()}usdt_{date}_depth5",
                f"{symbol.lower()}usdt_{date}_trade",
            )
            bt.run()
    else:
        date = dates[0] + "-" + dates[-1]
        bt = BacktesterHedge(date, config)
        log.info(f"date:{date}, saved in {bt.path}")
        book_files = [f"{symbol.lower()}usdt_{date}_depth5" for date in dates]
        trade_files = [f"{symbol.lower()}usdt_{date}_trade" for date in dates]
        bt.load_data(book_files, trade_files)
        bt.run()
    log.info("=" * 80 + "\n\n\n\n")
