import yaml

from bt.serial_hedge import *
from utils.tools import *


@main
def run(*args):
    with open("./config/test_hedge_eth.yaml", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    log.info(config)
    start = int(config["market_setting"]["start_date"])
    end = int(config["market_setting"]["end_date"])
    backtest_loop_hedge(config, start, end)
