import numpy as np
from sortedcontainers import SortedDict


class Book:
    def __init__(self, reverse=False):
        # reverse=True 为降序（BidBook），False 为升序（AskBook）
        self.open_orders = SortedDict()
        self.reverse = reverse
        self.total_volume = 0

    def apply_transactions(self, reference_price, time):
        raise NotImplementedError

    def update_book(self, prices: list, volume: list):
        raise NotImplementedError

    def place_order(self, price, size, type, ac_time):
        if price in self.open_orders:
            return False
        elif size == 0:
            return False
        else:
            self.open_orders[price] = (size, type, ac_time)
            self.total_volume += size  # 增量更新
            return True

    def cancel_order(self, price):
        if price not in self.open_orders:
            return False
        else:
            old_size = self.open_orders[price][0]
            del self.open_orders[price]
            self.total_volume -= old_size  # 增量更新
            return True

    def cancel_all_orders(self):
        self.open_orders.clear()
        self.total_volume = 0

    def cancel_worst(self):
        if self.open_orders:
            if self.reverse:
                del self.open_orders[self.open_orders.keys()[0]]  # 最小价格是最差的
            else:
                del self.open_orders[self.open_orders.keys()[-1]]  # 最大价格是最差的

    def get_order(self, price):
        return self.open_orders.get(price)

    def order_count(self):
        return len(self.open_orders)

    def is_empty(self):
        return len(self.open_orders) == 0

    @property
    def prices(self):
        if self.reverse:
            return list(reversed(self.open_orders.keys()))
        return list(self.open_orders.keys())

    @property
    def volume(self):
        if self.reverse:
            return [v[0] for v in reversed(self.open_orders.values())]
        return [v[0] for v in self.open_orders.values()]

    def best_open_order_price(self):
        if not self.open_orders:
            return None
        if self.reverse:
            return self.open_orders.keys()[-1]  # 降序：最大价格
        return self.open_orders.keys()[0]  # 升序：最小价格

    def worst_open_order_price(self):
        if not self.open_orders:
            return None
        if self.reverse:
            return self.open_orders.keys()[0]  # 降序：最小价格
        return self.open_orders.keys()[-1]  # 升序：最大价格

    def __str__(self):
        return f'Order Book: {dict(self.open_orders)}'


class AskBook(Book):
    def __init__(self):
        super(AskBook, self).__init__(reverse=False)

    def apply_transactions(self, reference_price, time):
        """AskBook: 卖单，价格从低到高排序，低于参考价的成交"""
        value = 0
        proxy = 0
        transaction_volume = 0
        order_done = []
        to_delete = []

        # SortedDict 按价格升序排列，遍历低于参考价的订单
        for level_price, (level_volume, level_type, level_ac_time) in self.open_orders.items():
            if level_price >= reference_price:
                break
            to_delete.append(level_price)
            transaction_volume += level_volume
            value += level_price * level_volume
            proxy += np.fabs(level_price - reference_price) * level_volume
            order_done.append((level_price, level_volume, level_type, level_ac_time))

        for price in to_delete:
            del self.open_orders[price]

        # 清理过期订单
        expired = [p for p, (_, _, ac_time) in self.open_orders.items() if time > ac_time]
        for price in expired:
            del self.open_orders[price]

        return -transaction_volume, proxy, value, order_done


class BidBook(Book):
    def __init__(self):
        super(BidBook, self).__init__(reverse=True)

    def apply_transactions(self, reference_price, time):
        """BidBook: 买单，需要高于参考价的成交（从高价开始）"""
        value = 0
        proxy = 0
        transaction_volume = 0
        order_done = []
        to_delete = []

        # SortedDict 按价格升序，我们需要从高价开始，所以逆序遍历
        for level_price, (level_volume, level_type, level_ac_time) in reversed(self.open_orders.items()):
            if level_price <= reference_price:
                break
            to_delete.append(level_price)
            transaction_volume += level_volume
            value += level_price * level_volume
            proxy += np.fabs(level_price - reference_price) * level_volume
            order_done.append((level_price, level_volume, level_type, level_ac_time))

        for price in to_delete:
            del self.open_orders[price]

        # 清理过期订单
        expired = [p for p, (_, _, ac_time) in self.open_orders.items() if time > ac_time]
        for price in expired:
            del self.open_orders[price]

        return transaction_volume, proxy, -value, order_done


class Depth:
    def __init__(self):
        self.prices = []
        self.last_prices = []

        self.volume = []
        self.last_volume = []

        self.total_volume = 0
        self.last_total_volume = 0

    def is_empty(self):
        return len(self.prices) == 0

    def reset(self):
        self.prices = []
        self.last_prices = []

        self.volume = []
        self.last_volume = []

        self.total_volume = 0
        self.last_total_volume = 0

    def stash_state(self):
        self.last_prices = self.prices
        self.last_volume = self.volume
        self.last_total_volume = self.total_volume

    def has_stash(self):
        return self.last_prices[0] > 1e-20

    def update(self, prices: list, volume: list):
        self.prices = prices
        self.volume = volume
        self.total_volume = sum(volume)

    @property
    def length(self):
        return len(self.prices)

    def __str__(self):
        return f'Depth: {[(self.prices[_], self.volume[_]) for _ in range(len(self.prices))]}'
