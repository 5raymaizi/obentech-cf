import os
import pandas as pd
import numpy as np
from enum import Enum, auto

# ===================== Enum 定义 =====================

class MyEnum(Enum):
    def _generate_next_value_(name, start, count, last_values):
        for last_value in reversed(last_values):
            try:
                return last_value + 1
            except TypeError:
                pass
        else:
            return 0

class SpotColumns(MyEnum):
    DATE, TIME = auto(), auto()
    ask_price0, ask_price1, ask_price2, ask_price3, ask_price4 = auto(), auto(), auto(), auto(), auto()
    ask_size0, ask_size1, ask_size2, ask_size3, ask_size4 = auto(), auto(), auto(), auto(), auto()
    bid_price0, bid_price1, bid_price2, bid_price3, bid_price4 = auto(), auto(), auto(), auto(), auto()
    bid_size0, bid_size1, bid_size2, bid_size3, bid_size4 = auto(), auto(), auto(), auto(), auto()

class SpotTradeColumns(MyEnum):
    ts = auto()
    e = auto()
    E = auto()
    T = auto()
    s = auto()
    a = auto()
    p = auto()
    q = auto()
    type = auto()
    m = auto()

class PerpColumns(MyEnum):
    DATE, TIME = auto(), auto()
    ask_price0, ask_price1, ask_price2, ask_price3, ask_price4 = auto(), auto(), auto(), auto(), auto()
    ask_size0, ask_size1, ask_size2, ask_size3, ask_size4 = auto(), auto(), auto(), auto(), auto()
    bid_price0, bid_price1, bid_price2, bid_price3, bid_price4 = auto(), auto(), auto(), auto(), auto()
    bid_size0, bid_size1, bid_size2, bid_size3, bid_size4 = auto(), auto(), auto(), auto(), auto()

class PerpTradeColumns(MyEnum):
    ts = auto()
    e = auto()
    E = auto()
    T = auto()
    s = auto()
    a = auto()
    p = auto()
    q = auto()
    type = auto()
    m = auto()

class FuturesColumns(MyEnum):
    DATE, TIME = auto(), auto()
    ask_price0, ask_price1, ask_price2, ask_price3, ask_price4 = auto(), auto(), auto(), auto(), auto()
    ask_size0, ask_size1, ask_size2, ask_size3, ask_size4 = auto(), auto(), auto(), auto(), auto()
    bid_price0, bid_price1, bid_price2, bid_price3, bid_price4 = auto(), auto(), auto(), auto(), auto()
    bid_size0, bid_size1, bid_size2, bid_size3, bid_size4 = auto(), auto(), auto(), auto(), auto()

class FuturesTradeColumns(MyEnum):
    ts = auto()
    exchange_time = auto()
    e = auto()
    E = auto()
    T = auto()
    s = auto()
    a = auto()
    p = auto()
    q = auto()
    type = auto()
    m = auto()

# 旧格式trade数据列名 (10列，无exchange_time)
_TRADE_COLUMNS_OLD = ['ts', 'e', 'E', 'T', 's', 'a', 'p', 'q', 'type', 'm']
# 新格式trade数据列名 (11列，有exchange_time)
_TRADE_COLUMNS_NEW = ['ts', 'exchange_time', 'e', 'E', 'T', 's', 'a', 'p', 'q', 'type', 'm']

# ===================== 通用Chunk加载器 =====================
class _ChunkedDataLoader:
    def __init__(self, paths, read_fn, columns):
        self.paths = paths
        self.read_fn = read_fn
        self.columns = columns
        self.df = None
        self.df_iterator = None
        self.cur_row = None
        self.next_row = None
        self.last_row = None
        self.cur_path_idx = -1
        self._load_next_file()

    def _load_next_file(self):
        self.cur_path_idx += 1
        if self.cur_path_idx < len(self.paths):
            self.df = self.read_fn(self.paths[self.cur_path_idx], self.columns)
            self.df_iterator = self.df.itertuples()
            # self.cur_row = None
            # self.next_row = None
            # self.last_row = None
        else:
            self.df = None
            self.df_iterator = None

    def load_next(self):
        while True:
            if self.df_iterator is None:
                return False
            try:
                if self.next_row is not None:
                    self.last_row = self.cur_row
                    self.cur_row = self.next_row
                    self.next_row = next(self.df_iterator)
                else:
                    self.last_row = next(self.df_iterator)
                    self.cur_row = next(self.df_iterator)
                    self.next_row = next(self.df_iterator)
                return True
            except StopIteration:
                self._load_next_file()
                if self.df_iterator is None:
                    return False
                else:
                    self.next_row = next(self.df_iterator)
                    return True

    def skip_n(self, n=1):
        for _ in range(n):
            if not self.load_next():
                break

    def get_cur_row(self):
        return self.cur_row

    def get_next_row(self):
        return self.next_row

    def get_last_row(self):
        return self.last_row

# ===================== 读取函数 =====================
def _read_depth_parquet(path, columns):
    df_tmp = pd.read_parquet(path)
    df_tmp['received_time'] = pd.to_datetime(df_tmp['received_time'])
    df_tmp['date'] = df_tmp['received_time'].dt.date
    selected = ['date', 'received_time', 'ask_price0', 'ask_price1', 'ask_price2', 'ask_price3', 'ask_price4',
                'ask_size0', 'ask_size1', 'ask_size2', 'ask_size3', 'ask_size4', 'bid_price0', 'bid_price1',
                'bid_price2', 'bid_price3', 'bid_price4', 'bid_size0', 'bid_size1', 'bid_size2', 'bid_size3',
                'bid_size4']
    df_tmp = df_tmp[selected]
    df_tmp.columns = columns
    return df_tmp

def _read_depth_csv(path, columns):
    df_tmp = pd.read_csv(path)
    df_tmp['received_time'] = pd.to_datetime(df_tmp['received_time'])
    df_tmp['date'] = df_tmp['received_time'].apply(lambda x: x.date()).values
    selected = ['date', 'received_time', 'ask_price0', 'ask_price1', 'ask_price2', 'ask_price3', 'ask_price4',
                'ask_size0', 'ask_size1', 'ask_size2', 'ask_size3', 'ask_size4', 'bid_price0', 'bid_price1',
                'bid_price2', 'bid_price3', 'bid_price4', 'bid_size0', 'bid_size1', 'bid_size2', 'bid_size3',
                'bid_size4']
    df_tmp = df_tmp[selected]
    df_tmp.columns = columns
    return df_tmp

def _read_trade_parquet(path, columns):
    df_tmp = pd.read_parquet(path)
    # 自动适配新旧格式：10列(旧)或11列(新)
    if len(df_tmp.columns) == 10:
        df_tmp.columns = _TRADE_COLUMNS_OLD
    elif len(df_tmp.columns) == 11:
        df_tmp.columns = _TRADE_COLUMNS_NEW
    else:
        df_tmp.columns = columns  # fallback
    df_tmp.loc[:, 'ts'] = pd.to_datetime(df_tmp['ts'])
    df_tmp = df_tmp[df_tmp['p'] > 0]
    return df_tmp

def _read_trade_csv(path, columns):
    df_tmp = pd.read_csv(path)
    # 自动适配新旧格式：10列(旧)或11列(新)
    if len(df_tmp.columns) == 10:
        df_tmp.columns = _TRADE_COLUMNS_OLD
    elif len(df_tmp.columns) == 11:
        df_tmp.columns = _TRADE_COLUMNS_NEW
    else:
        df_tmp.columns = columns  # fallback
    df_tmp.loc[:, 'ts'] = pd.to_datetime(df_tmp['ts'])
    df_tmp = df_tmp[df_tmp['p'] > 0]
    return df_tmp

# ===================== SpotMarketDepth =====================
class SpotMarketDepth:
    def __init__(self):
        self.columns = SpotColumns._member_names_
        self.loader = None

    def load_dataset(self, name, symbol, exchange='binance', mkt='spot', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/books/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        path = os.path.join(base_dir, f'{name}.{ext}')
        self.loader = _ChunkedDataLoader([path], _read_depth_parquet if file_type == 'parquet' else _read_depth_csv, self.columns)
        self.load_next()

    def load_datasets(self, names, symbol, exchange='binance', mkt='spot', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/books/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        paths = [os.path.join(base_dir, f'{name}.{ext}') for name in names]
        self.loader = _ChunkedDataLoader(paths, _read_depth_parquet if file_type == 'parquet' else _read_depth_csv, self.columns)
        self.load_next()

    def load_next(self): return self.loader.load_next()
    def skip_n(self, n=1): return self.loader.skip_n(n)
    def get_cur_row(self): return self.loader.get_cur_row()
    def get_next_row(self): return self.loader.get_next_row()
    def get_last_row(self): return self.loader.get_last_row()

    @property
    def ask_prices(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, SpotColumns(i).name) for i in range(2, 7)] if cur_row is not None else 0

    @property
    def ask_volume(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, SpotColumns(i).name) for i in range(7, 12)] if cur_row is not None else 0

    @property
    def bid_prices(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, SpotColumns(i).name) for i in range(12, 17)] if cur_row is not None else 0

    @property
    def bid_volume(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, SpotColumns(i).name) for i in range(17, 22)] if cur_row is not None else 0

    @property
    def cur_date(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, SpotColumns(0).name) if cur_row is not None else 0

    @property
    def cur_time(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, SpotColumns(1).name) if cur_row is not None else 0

    @property
    def next_date(self):
        next_row = self.get_next_row()
        return getattr(next_row, SpotColumns(0).name) if next_row is not None else 0

    @property
    def next_time(self):
        next_row = self.get_next_row()
        return getattr(next_row, SpotColumns(1).name) if next_row is not None else 0

    @property
    def final_time(self):
        return None

# ===================== SpotMarketTrade =====================
class SpotMarketTrade:
    def __init__(self):
        self.columns = SpotTradeColumns._member_names_
        self.loader = None

    def load_dataset(self, name, symbol, exchange='binance', mkt='spot', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/trade/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        path = os.path.join(base_dir, f'{name}.{ext}')
        self.loader = _ChunkedDataLoader([path], _read_trade_parquet if file_type == 'parquet' else _read_trade_csv, self.columns)
        self.load_next()

    def load_datasets(self, names, symbol, exchange='binance', mkt='spot', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/trade/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        paths = [os.path.join(base_dir, f'{name}.{ext}') for name in names]
        self.loader = _ChunkedDataLoader(paths, _read_trade_parquet if file_type == 'parquet' else _read_trade_csv, self.columns)
        self.load_next()

    def load_next(self): return self.loader.load_next()
    def skip_n(self, n=1): return self.loader.skip_n(n)
    def get_cur_row(self): return self.loader.get_cur_row()
    def get_next_row(self): return self.loader.get_next_row()
    def get_last_row(self): return self.loader.get_last_row()

    @property
    def price(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, SpotTradeColumns(6).name) if cur_row is not None else 0

    @property
    def volume(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, SpotTradeColumns(7).name) if cur_row is not None else 0

    @property
    def orderId_b(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, SpotTradeColumns(5).name) if cur_row is not None else 0

    @property
    def orderId_a(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, SpotTradeColumns(5).name) if cur_row is not None else 0

    @property
    def side(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, SpotTradeColumns(9).name) if cur_row is not None else 0

    @property
    def cur_time(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, SpotTradeColumns(0).name) if cur_row is not None else 0

    @property
    def next_time(self):
        next_row = self.get_next_row()
        return getattr(next_row, SpotTradeColumns(0).name) if next_row is not None else 0

    @property
    def final_time(self):
        return None

# ===================== PerpMarketDepth =====================
class PerpMarketDepth:
    def __init__(self):
        self.columns = PerpColumns._member_names_
        self.loader = None

    def load_dataset(self, name, symbol, exchange='binance', mkt='perp', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/books/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        path = os.path.join(base_dir, f'{name}.{ext}')
        self.loader = _ChunkedDataLoader([path], _read_depth_parquet if file_type == 'parquet' else _read_depth_csv, self.columns)
        self.load_next()

    def load_datasets(self, names, symbol, exchange='binance', mkt='perp', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/books/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        paths = [os.path.join(base_dir, f'{name}.{ext}') for name in names]
        self.loader = _ChunkedDataLoader(paths, _read_depth_parquet if file_type == 'parquet' else _read_depth_csv, self.columns)
        self.load_next()

    def load_next(self): return self.loader.load_next()
    def skip_n(self, n=1): return self.loader.skip_n(n)
    def get_cur_row(self): return self.loader.get_cur_row()
    def get_next_row(self): return self.loader.get_next_row()
    def get_last_row(self): return self.loader.get_last_row()

    @property
    def ask_prices(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, PerpColumns(i).name) for i in range(2, 7)] if cur_row is not None else 0

    @property
    def ask_volume(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, PerpColumns(i).name) for i in range(7, 12)] if cur_row is not None else 0

    @property
    def bid_prices(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, PerpColumns(i).name) for i in range(12, 17)] if cur_row is not None else 0

    @property
    def bid_volume(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, PerpColumns(i).name) for i in range(17, 22)] if cur_row is not None else 0

    @property
    def cur_date(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, PerpColumns(0).name) if cur_row is not None else 0

    @property
    def cur_time(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, PerpColumns(1).name) if cur_row is not None else 0

    @property
    def next_date(self):
        next_row = self.get_next_row()
        return getattr(next_row, PerpColumns(0).name) if next_row is not None else 0

    @property
    def next_time(self):
        next_row = self.get_next_row()
        return getattr(next_row, PerpColumns(1).name) if next_row is not None else 0

    @property
    def final_time(self):
        return None

# ===================== PerpMarketTrade =====================
class PerpMarketTrade:
    def __init__(self):
        self.columns = PerpTradeColumns._member_names_
        self.loader = None

    def load_dataset(self, name, symbol, exchange='binance', mkt='perp', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/trade/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        path = os.path.join(base_dir, f'{name}.{ext}')
        self.loader = _ChunkedDataLoader([path], _read_trade_parquet if file_type == 'parquet' else _read_trade_csv, self.columns)
        self.load_next()

    def load_datasets(self, names, symbol, exchange='binance', mkt='perp', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/trade/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        paths = [os.path.join(base_dir, f'{name}.{ext}') for name in names]
        self.loader = _ChunkedDataLoader(paths, _read_trade_parquet if file_type == 'parquet' else _read_trade_csv, self.columns)
        self.load_next()

    def load_next(self): return self.loader.load_next()
    def skip_n(self, n=1): return self.loader.skip_n(n)
    def get_cur_row(self): return self.loader.get_cur_row()
    def get_next_row(self): return self.loader.get_next_row()
    def get_last_row(self): return self.loader.get_last_row()

    @property
    def price(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, PerpTradeColumns(6).name) if cur_row is not None else 0

    @property
    def volume(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, PerpTradeColumns(7).name) if cur_row is not None else 0

    @property
    def orderId_b(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, PerpTradeColumns(5).name) if cur_row is not None else 0

    @property
    def orderId_a(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, PerpTradeColumns(5).name) if cur_row is not None else 0

    @property
    def side(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, PerpTradeColumns(9).name) if cur_row is not None else 0

    @property
    def cur_time(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, PerpTradeColumns(0).name) if cur_row is not None else 0

    @property
    def next_time(self):
        next_row = self.get_next_row()
        return getattr(next_row, PerpTradeColumns(0).name) if next_row is not None else 0

    @property
    def final_time(self):
        return None

# ===================== FuturesMarketDepth =====================
# 预先缓存 depth 列名
_DEPTH_COL_DATE = FuturesColumns(0).name  # DATE
_DEPTH_COL_TIME = FuturesColumns(1).name  # TIME

class FuturesMarketDepth:
    def __init__(self):
        self.columns = FuturesColumns._member_names_
        self.loader = None

    def load_dataset(self, name, symbol, exchange='binance', mkt='perp', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/books/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        path = os.path.join(base_dir, f'{name}.{ext}')
        self.loader = _ChunkedDataLoader([path], _read_depth_parquet if file_type == 'parquet' else _read_depth_csv, self.columns)
        self.load_next()

    def load_datasets(self, names, symbol, exchange='binance', mkt='perp', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/books/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        paths = [os.path.join(base_dir, f'{name}.{ext}') for name in names]
        self.loader = _ChunkedDataLoader(paths, _read_depth_parquet if file_type == 'parquet' else _read_depth_csv, self.columns)
        self.load_next()

    def load_next(self): return self.loader.load_next()
    def skip_n(self, n=1): return self.loader.skip_n(n)
    def get_cur_row(self): return self.loader.get_cur_row()
    def get_next_row(self): return self.loader.get_next_row()
    def get_last_row(self): return self.loader.get_last_row()

    @property
    def ask_prices(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, FuturesColumns(i).name) for i in range(2, 7)] if cur_row is not None else 0

    @property
    def ask_volume(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, FuturesColumns(i).name) for i in range(7, 12)] if cur_row is not None else 0

    @property
    def bid_prices(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, FuturesColumns(i).name) for i in range(12, 17)] if cur_row is not None else 0

    @property
    def bid_volume(self):
        cur_row = self.get_cur_row()
        return [getattr(cur_row, FuturesColumns(i).name) for i in range(17, 22)] if cur_row is not None else 0

    @property
    def cur_date(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, _DEPTH_COL_DATE) if cur_row is not None else 0

    @property
    def cur_time(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, _DEPTH_COL_TIME) if cur_row is not None else 0

    @property
    def next_date(self):
        next_row = self.get_next_row()
        return getattr(next_row, _DEPTH_COL_DATE) if next_row is not None else 0

    @property
    def next_time(self):
        next_row = self.get_next_row()
        return getattr(next_row, _DEPTH_COL_TIME) if next_row is not None else 0

    @property
    def final_time(self):
        return None

# ===================== FuturesMarketTrade =====================
# 预先缓存列名，直接使用字符串以兼容新旧格式
_TRADE_COL_TS = 'ts'
_TRADE_COL_PRICE = 'p'
_TRADE_COL_VOLUME = 'q'
_TRADE_COL_SIDE = 'm'
_TRADE_COL_ORDERID = 'a'

class FuturesMarketTrade:
    def __init__(self):
        self.columns = FuturesTradeColumns._member_names_
        self.loader = None

    def load_dataset(self, name, symbol, exchange='binance', mkt='perp', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/trade/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        path = os.path.join(base_dir, f'{name}.{ext}')
        self.loader = _ChunkedDataLoader([path], _read_trade_parquet if file_type == 'parquet' else _read_trade_csv, self.columns)
        self.load_next()

    def load_datasets(self, names, symbol, exchange='binance', mkt='perp', file_type='parquet', data_path='./data'):
        base_dir = f'{data_path}/{exchange}/{mkt}/trade/{symbol}'
        ext = 'parquet' if file_type == 'parquet' else 'csv'
        paths = [os.path.join(base_dir, f'{name}.{ext}') for name in names]
        self.loader = _ChunkedDataLoader(paths, _read_trade_parquet if file_type == 'parquet' else _read_trade_csv, self.columns)
        self.load_next()

    def load_next(self): return self.loader.load_next()
    def skip_n(self, n=1): return self.loader.skip_n(n)
    def get_cur_row(self): return self.loader.get_cur_row()
    def get_next_row(self): return self.loader.get_next_row()
    def get_last_row(self): return self.loader.get_last_row()

    @property
    def price(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, _TRADE_COL_PRICE) if cur_row is not None else 0

    @property
    def volume(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, _TRADE_COL_VOLUME) if cur_row is not None else 0

    @property
    def orderId_b(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, _TRADE_COL_ORDERID) if cur_row is not None else 0

    @property
    def orderId_a(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, _TRADE_COL_ORDERID) if cur_row is not None else 0

    @property
    def side(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, _TRADE_COL_SIDE) if cur_row is not None else 0

    @property
    def cur_time(self):
        cur_row = self.get_cur_row()
        return getattr(cur_row, _TRADE_COL_TS) if cur_row is not None else 0

    @property
    def next_time(self):
        next_row = self.get_next_row()
        return getattr(next_row, _TRADE_COL_TS) if next_row is not None else 0

    @property
    def final_time(self):
        return None
