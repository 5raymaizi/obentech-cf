from collections import deque
from datetime import timedelta


class TradeFlow:
    def __init__(self, max_len=10):
        self.max_len = max_len
        self.trade_price = deque(maxlen=self.max_len)
        self.trade_volume = deque(maxlen=self.max_len)
        self.trade_time = deque(maxlen=self.max_len)
        self.trade_sell_price = deque(maxlen=self.max_len)
        self.trade_sell_volume = deque(maxlen=self.max_len)
        self.trade_sell_time = deque(maxlen=self.max_len)
        self.trade_buy_price = deque(maxlen=self.max_len)
        self.trade_buy_volume = deque(maxlen=self.max_len)
        self.trade_buy_time = deque(maxlen=self.max_len)

    def reset(self):
        self.trade_price = deque(maxlen=self.max_len)
        self.trade_volume = deque(maxlen=self.max_len)
        self.trade_time = deque(maxlen=self.max_len)
        self.trade_sell_price = deque(maxlen=self.max_len)
        self.trade_sell_volume = deque(maxlen=self.max_len)
        self.trade_sell_time = deque(maxlen=self.max_len)
        self.trade_buy_price = deque(maxlen=self.max_len)
        self.trade_buy_volume = deque(maxlen=self.max_len)
        self.trade_buy_time = deque(maxlen=self.max_len)

    def push(self, price, volume, time, side):
        self.trade_price.appendleft(price)
        self.trade_volume.appendleft(volume)
        self.trade_time.appendleft(time)
        assert side in ['sell', 'buy', 0, 1], f'{side}'
        if side == 'sell' or side == 0:
            self.trade_sell_price.appendleft(price)
            self.trade_sell_volume.appendleft(volume)
            self.trade_sell_time.appendleft(time)
        else:
            self.trade_buy_price.appendleft(price)
            self.trade_buy_volume.appendleft(volume)
            self.trade_buy_time.appendleft(time)

    def is_full(self):
        return len(self.trade_price) == self.max_len


# class Trades():
#     def __init__(self, window_size: int, side: str):
#         self._window_price = deque()
#         self._window_volume = deque()
#         self._window_size = window_size
#         # self._average_price = 0
#         self._val = 0
#         self._volume = 0
#         self.side = side
#
#     def push(self, trade: tuple):
#         if self.size == self._window_size:
#             # raise Exception("this list is full")
#             return False
#         price = trade[0]
#         volume = trade[1]
#         self._window_price.appendleft(price)
#         self._window_volume.appendleft(volume)
#         self._val += price * volume
#         self._volume += volume
#         return True
#
#     @property
#     def cost(self):
#         return self._val / self._volume
#
#     @property
#     def volume(self):
#         return self._volume
#
#     @property
#     def size(self):
#         return len(self._window_price)
#
#     @property
#     def front(self):
#         return (self._window_price[0], self._window_volume[0]) if self.size > 0 else -1
#
#     @property
#     def back(self):
#         return (self._window_price[-1], self._window_volume[-1]) if self.size > 0 else -1
#
#     def reset(self):
#         self._window_price = deque()
#         self._window_volume = deque()
#         # self._average_price = 0
#         self._val = 0
#         self._volume = 0
#
#     def is_full(self):
#         return self.size == self._window_size
#
#     def is_empty(self):
#         return self.size == 0
#
#     def __getitem__(self, i):
#         return (self._window_price[i], self._window_volume[i]) if i < self.size else -1
#
#
# class TradesList():
#     def __init__(self, window_size: int, trades_size:5, side: str):
#         # self.window = deque(maxlen=_window_size)
#         self._window_trades = []
#         self.ts = []
#         self._window_size = window_size
#         self.trades_size = trades_size
#         self.side = side
#
#     def push(self, trade: tuple, ts):
#         if self.is_empty():
#             self._window_trades.append(Trades(self.trades_size, self.side))
#             self._window_trades[-1].push(trade)
#             self.ts.append(ts)
#         else:
#             if not self._window_trades[-1].push(trade):
#                 if self.size == self._window_size:
#                     raise Exception("this list is full")
#                 else:
#                     self._window_trades.append(Trades(self.trades_size, self.side))
#                     self._window_trades[-1].push(trade)
#                     self.ts.append(ts)
#
#     @property
#     def size(self):
#         return len(self._window_trades)
#
#     def is_empty(self):
#         return self.size == 0
#
#     def is_full(self):
#         return self.size == self._window_size
#
#     @property
#     def front(self):
#         return (self._window_trades[0], self._window_trades[0]) if self.size > 0 else -1
#
#     @property
#     def back(self):
#         return (self._window_trades[-1], self._window_trades[-1]) if self.size > 0 else -1
#
#     def reset(self):
#         self._window_trades = []
#
#     def remove(self, ts):
#         index = self.ts.index(ts)
#         self.ts.pop(index)
#         trade = self._window_trades.pop(index)
#         return trade._window_price, ts
#
#     def __str__(self):
#         return f'Orders: {[(self._window_trades[_]._window_price, self.ts[_]) for _ in range(self.size)]}'


class ImpactTrade:
    def __init__(self, sec_limit=30):
        self._orderID = deque()
        self._orderInfo = {}
        self._orderTimestamp = deque()
        self.sec_limit = sec_limit
        self._total_quantity = 0
        self._total_value = 0

    def reset(self):
        self._orderID = deque()
        self._orderInfo = {}
        self._orderTimestamp = deque()
        self._total_quantity = 0
        self._total_value = 0

    def push(self, id, ts, quantity, value):
        if id in self._orderID:
            last_quantity, last_value = self._orderInfo[id]
            self._orderInfo[id] = [last_quantity + quantity, last_value + value]
            self._total_quantity += quantity
            self._total_value += value
        elif self._orderTimestamp and ts - self._orderTimestamp[-1] > timedelta(seconds=self.sec_limit):
            # print(self._orderTimestamp)
            while self._orderTimestamp and ts - self._orderTimestamp[-1] > timedelta(seconds=self.sec_limit):
                # del self._orderInfo[self._orderID.pop()]
                self._orderTimestamp.pop()
                q, v = self._orderInfo.pop(self._orderID.pop())
                self._total_quantity -= q
                self._total_value -= v
            # print(self._orderTimestamp)
            self._total_quantity += quantity
            self._total_value += value
            self._orderID.appendleft(id)
            self._orderTimestamp.appendleft(ts)
            self._orderInfo[id] = [quantity, value]
        else:
            self._orderID.appendleft(id)
            self._orderTimestamp.appendleft(ts)
            self._orderInfo[id] = [quantity, value]
            self._total_quantity += quantity
            self._total_value += value

    @property
    def quantity(self):
        return self._total_quantity

    @property
    def avg_price(self):
        try:
            return self._total_value / self._total_quantity
        except ZeroDivisionError:
            return 0

    @property
    def impact_quantity(self, limit=0.1):
        quantity = 0
        for q, v in self._orderInfo.values():
            if q >= limit:
                quantity += q
        return q

    @property
    def impact_price(self, limit=0.1):
        quantity = 0
        value = 0
        for q, v in self._orderInfo.values():
            if q > limit:
                quantity += q
                value += v
        try:
            return value / quantity, quantity
        except ZeroDivisionError:
            return 0, 0


class TradeByPrice:
    def __init__(self):
        self._orderInfo = {}

    def reset(self):
        self._orderInfo = {}

    def push(self, price, volume):
        if price in self._orderInfo.keys():
            self._orderInfo[price] = self._orderInfo[price] + volume
        else:
            self._orderInfo[price] = volume

    def max(self):
        if not self.is_empty():
            return max(list(self._orderInfo.values()))
        else:
            return 0

    def is_empty(self):
        return len(self._orderInfo) == 0


class TradeByTick:
    def __init__(self):
        self._orderInfo = []

    def reset(self):
        self._orderInfo = []

    def push(self, price):
        self._orderInfo.append(price)
        # if ts in self._orderInfo.keys():
        #     self._orderInfo[ts].append(price)
        # else:
        #     self._orderInfo[ts] = [price]

    # def max(self):
    #     if not self.is_empty():
    #         return max(list(self._orderInfo.values()))
    #     else:
    #         return 0

    @property
    def vol(self):
        if not self.is_empty():
            # return max(self._orderInfo) - min(self._orderInfo)
            return self._orderInfo[-1] - self._orderInfo[0]
        else:
            return 0

    def is_empty(self):
        return len(self._orderInfo) == 0
